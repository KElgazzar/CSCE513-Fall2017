CMPS 499/513 Semester Project 2017
Project : LoRa Fire Detection and Environment Monitoring System
Names : Jesse Broussard, Brock Landry, Brian Okoye

First it is **important** to note when using this on mbed's website, you **must revert the version number of mbed-os to the June 07, 2017 version** of the library using revision options.
Otherwise the code will not work due to version mismatch between mDot library and the Mbed OS library.

Secondly, our code is adapted off of example code given by Multitech that they use to explain how their device works.  Unfortunately this is about all the information they give on how their device works,
as documentation does not contain how their api works, nor do they have an api page for their mDot libraries.  This is why we chose to adapt the code to work with what we we're attempting to accomplish.

The starting project that Multitech supplies is called "Dot Examples".

The starting code implements a basic template for connecting to the gateway, as well as information for setting up the gateway to run with the correct
frequency plan (US vs Australia vs UK frequency band plans etc.).  Using this code is pretty much the only safe way to ensure the gateway and node 
will operate as intended from what I can tell as multitech does not supply any other starting/tutorial code, which considering the device's cost ($$$), operation outside
of this program could cause damage to the device which is something we were not willing to risk due liability for damage.

To access our code, view the file named "ota_example.cpp" inside of the src folder.

This file origionally contained code for turning an light sensor on and off, but we removed that and reworked to control our smoke and temperature sensor.  Due to 
the nature of the way they have these files set up, we chose not to rename ota_example.cpp to avoid breaking any possible connections the name has with the libraries
provided by multitech.

To do so we changed the way the i2c was currently set up, as the example code essentially hardwired their sensor to be the only working sensor on i2c,
then added in the ability for the smoke sensor to work on analog signal read.

We then used the mBed community "open source" libraries that have been built to handle just about every device under the sun, to find a library for both the MQ2, and htu21d.  After determining how these libraries
worked, the code was written to read and save the values of both the smoke sensor (MQ2) and the humidity and temperature sensor (htu21d), and then compare the values to a select set of values called "threshold values"
or "trip points" (terms we use in C.A.P.E.)which are basically limits at which if the value goes above or below, it will create a message by filling a vector with characters denoting a warning message, and then passing
that vector to a function called send_data() which is part of the dot_util.cpp library provided by multitech.  The send_data() function transmits the char array to the conduit, which then parses the code.

Finally after sending data, the node will sleep itself and upon resuming will run through the code repeating the process above, comparing the values to trip points and taking action if needed.

If you have any questions feel free to email me at : 
jab3352@louisiana.edu
