//CMPS 499/513
//Project : LoRa Fire Detection and Environment Monitoring System
//The following code is from an example provided by multitech to showcase the abilities of
//the mDot
//
//We used this code as a starting point in both learning how the
//mDot works, as there is not much other documentation, as well
//as a starting point for implementing the mDot sensory node used
//in the project.

//This file contains the information needed to run the mDot
//including the set up of both sensors, the peripherals used
//the reading, and trip point threshold checking of the sensors
//as well as the sending of the data to the conduit using
//the dot_util.cpp file provided by Multitech to control the driver
//for LoRa on the mDot.

#include "dot_util.h"
#include "RadioEvent.h"
#include "mbed.h"
#include "MQ2.h"
#include "htu21d.h"

#if ACTIVE_EXAMPLE == OTA_EXAMPLE

/////////////////////////////////////////////////////////////////////////////
// -------------------- DOT LIBRARY REQUIRED ------------------------------//
// * Because these example programs can be used for both mDot and xDot     //
//     devices, the LoRa stack is not included. The libmDot library should //
//     be imported if building for mDot devices. The libxDot library       //
//     should be imported if building for xDot devices.                    //
// * https://developer.mbed.org/teams/MultiTech/code/libmDot-dev-mbed5/    //
// * https://developer.mbed.org/teams/MultiTech/code/libmDot-mbed5/        //
// * https://developer.mbed.org/teams/MultiTech/code/libxDot-dev-mbed5/    //
// * https://developer.mbed.org/teams/MultiTech/code/libxDot-mbed5/        //
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
// * these options must match the settings on your gateway //
// * edit their values to match your configuration         //
// * frequency sub band is only relevant for the 915 bands //
// * either the network name and passphrase can be used or //
//     the network ID (8 bytes) and KEY (16 bytes)         //
/////////////////////////////////////////////////////////////

//LoRa Gateway login username
static std::string network_name = "ragincajuns";  
//LoRa Gateway login password
static std::string network_passphrase = "password";

static uint8_t frequency_sub_band = 0;
static bool public_network = false;
static uint8_t ack = 0;
static bool adr = true;

static bool deep_sleep = false;

//Initializes the variables that will be used to house the lora plan(US 915mHz) and the mDot class pointer.
mDot* dot = NULL;
lora::ChannelPlan* plan = NULL;

//UART Serial initialization
Serial pc(USBTX, USBRX);

//Project sensors, the MQ2 gas sensor, and the HTU21D temperature and humidity sensor.
//Initialization for each with pin numbers.
MQ2 mq2(XBEE_AD1);
htu21d tempHum(I2C_SDA, I2C_SCL);

//I2C in and out peripheral initialization
#if defined(TARGET_XDOT_L151CC)
ISL29011 lux(i2c);
#else
AnalogIn lux(XBEE_AD0);
#endif

int main() {
    
    // Custom event handler for automatically displaying RX data
    RadioEvent events;
    
    //Serial baud rate is set - 
    //pc: the Serial object listed above.
    //115200: the baud rate at which serial is operating.
    pc.baud(115200);
    
    //Not a clue what this does
    mts::MTSLog::setLogLevel(mts::MTSLog::TRACE_LEVEL);
    
//Our plan will be the ChannelPlan_US915
#if CHANNEL_PLAN == CP_US915
    plan = new lora::ChannelPlan_US915();
#elif CHANNEL_PLAN == CP_AU915
    plan = new lora::ChannelPlan_AU915();
#elif CHANNEL_PLAN == CP_EU868
    plan = new lora::ChannelPlan_EU868();
#elif CHANNEL_PLAN == CP_KR920
    plan = new lora::ChannelPlan_KR920();
#elif CHANNEL_PLAN == CP_AS923
    plan = new lora::ChannelPlan_AS923();
#elif CHANNEL_PLAN == CP_AS923_JAPAN
    plan = new lora::ChannelPlan_AS923_Japan();
#elif CHANNEL_PLAN == CP_IN865
    plan = new lora::ChannelPlan_IN865();
#endif
    assert(plan);

    //Initializes the LoRa stack on the mDot
    dot = mDot::getInstance(plan);
    assert(dot);

    // attach the custom events handler
    dot->setEvents(&events);

    //Debug information setup
    //Initialization of the mDot, including the connection settings
    //to the gateway.
    if (!dot->getStandbyFlag()) {
        logInfo("mbed-os library version: %d", MBED_LIBRARY_VERSION);

        logInfo("defaulting Dot configuration");
        dot->resetConfig();
        dot->resetNetworkSession();

        dot->setLogLevel(mts::MTSLog::INFO_LEVEL);

        if (dot->getJoinMode() != mDot::OTA) {
            logInfo("changing network join mode to OTA");
            if (dot->setJoinMode(mDot::OTA) != mDot::MDOT_OK) {
                logError("failed to set network join mode to OTA");
            }
        }
        update_ota_config_name_phrase(network_name, network_passphrase, frequency_sub_band, public_network, ack);
        update_network_link_check_config(3, 5);
        dot->setAdr(adr);
        logInfo("saving configuration");
        if (!dot->saveConfig()) {
            logError("failed to save configuration");
        }
        display_config();
    } else {
        logInfo("restoring network session from NVM");
        dot->restoreNetworkSession();
    }
         
    mq2.begin();

    while (true) {
        // join network if not joined
        if (!dot->getNetworkJoinStatus()) {
            join_network();           
        }

        //allows time for sensors and stuff to turn on correctly.
        wait(5);
        logInfo("\r\n\r\n\r\n Data From mDot : \r\n");
        
        //mq2 - mq2 sensor - uses mq2 library
        //tempHum - HTU21D sensor - uses HTU21D Library
        
        std::vector<uint8_t> smkTBuffer;       
        float smoke = mq2.readSmoke();
        int is = (int)smoke;
        logInfo("Smoke Value: %i", is);
        if(is > 500 & smoke < 1500){
            //Lower ppm of smoke detected
            logInfo("Low ppm of smoke detected, transmitting to gateway.");
            smkTBuffer.push_back('n');
            smkTBuffer.push_back(':');
            smkTBuffer.push_back('0');
            smkTBuffer.push_back('0');
            smkTBuffer.push_back(':');
            smkTBuffer.push_back('s');
            smkTBuffer.push_back(':');
            smkTBuffer.push_back('l');            
            send_data(smkTBuffer);   
            wait(3);              
            }
        else if(is > 1500){
            //Higher ppm of smoke detected
            logInfo("high ppm of smoke detected, transmitting to gateway.");
            smkTBuffer.push_back('n');
            smkTBuffer.push_back(':');
            smkTBuffer.push_back('0');
            smkTBuffer.push_back('0');
            smkTBuffer.push_back(':');
            smkTBuffer.push_back('s');
            smkTBuffer.push_back(':');
            smkTBuffer.push_back('h');     
            send_data(smkTBuffer);   
            wait(3);   
            }
        else{
           logInfo("None dangerous log for smoke...");
          }
        

////////////////////////////////////////////////////////////////// temperature sensor control code                             
        std::vector<uint8_t> tmpTBuffer;   
        float t  = tempHum.getTemp();
        int it = (int)t;
        it = it*1.8 +32;
        logInfo("Temperature Value: %i", it);        
        if(it > 150){
            //high temperature detected
            logInfo("high dangerous temperature detected detected, transmitting to gateway.");
            tmpTBuffer.push_back('n');
            tmpTBuffer.push_back(':');
            tmpTBuffer.push_back('0');
            tmpTBuffer.push_back('0');
            tmpTBuffer.push_back(':');
            tmpTBuffer.push_back('t');
            tmpTBuffer.push_back(':');
            tmpTBuffer.push_back('h');            
            send_data(tmpTBuffer);   
            wait(5);              
            }
        else if(it > 100 & it < 150){
            //mid temperature detected
            logInfo("low dangerous temperature detected, transmitting to gateway.");
            tmpTBuffer.push_back('n');
            tmpTBuffer.push_back(':');
            tmpTBuffer.push_back('0');
            tmpTBuffer.push_back('0');
            tmpTBuffer.push_back(':');
            tmpTBuffer.push_back('t');
            tmpTBuffer.push_back(':');
            tmpTBuffer.push_back('l');     
            send_data(tmpTBuffer);   
            wait(5);   
            }
        else{
           logInfo("Non-dangerous log for temperature...");
          //Smoke not detected
            }

////////////////////////////////////////////////////////////////// humidity sensor control code
        std::vector<uint8_t> humTBuffer; 
        float hu = tempHum.getHum();
        int ih = (int) hu;
        logInfo("Humidity Value: %i", ih);     
        if(ih < 35 & ih >= 15){
            //Lower ppm of smoke detected
            logInfo("medium dangerous humidity detected detected, transmitting to gateway.");
            humTBuffer.push_back('n');
            humTBuffer.push_back(':');
            humTBuffer.push_back('0');
            humTBuffer.push_back('0');
            humTBuffer.push_back(':');
            humTBuffer.push_back('h');
            humTBuffer.push_back(':');
            humTBuffer.push_back('m');            
            send_data(humTBuffer);   
            wait(5);              
            }
        else if(ih < 15){
            //Higher ppm of smoke detected
            logInfo("low dangerous humidity detected, transmitting to gateway.");
            humTBuffer.push_back('n');
            humTBuffer.push_back(':');
            humTBuffer.push_back('0');
            humTBuffer.push_back('0');
            humTBuffer.push_back(':');
            humTBuffer.push_back('h');
            humTBuffer.push_back(':');
            humTBuffer.push_back('l');     
            send_data(humTBuffer);   
            wait(5);   
            }
        else{
           logInfo("Non-dangerous log for humidity...");
          //Smoke not detected
            }
            
        // if going into deepsleep mode, save the session so we don't need to join again after waking up
        // not necessary if going into sleep mode since RAM is retained
        if (deep_sleep) {
            logInfo("saving network session to NVM");
            dot->saveNetworkSession();
        }
        
        //puts the mbed to sleep. (reduced power consumption)
        sleep_wake_rtc_or_interrupt(deep_sleep);
    }
 
    return 0;
}

#endif
