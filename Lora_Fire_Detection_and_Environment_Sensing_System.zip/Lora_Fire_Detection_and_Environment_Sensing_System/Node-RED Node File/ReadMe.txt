To load the nodes into node read,
Find the Import from Clipboard option, normally found at the top right corner menu of Node-RED

Select import from clipboard, and paste the information inside of the text file found in this folder, to generate the same nodes.
Twitter Authentication must be redone under new credentials (as Brian has the current credentials) , but the code will work.

If you have any questions email me at :
jab3352@louisiana.edu