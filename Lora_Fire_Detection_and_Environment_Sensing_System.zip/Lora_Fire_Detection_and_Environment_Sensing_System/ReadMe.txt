Contains code for: 

mDot side of our project, located in mDot.
	Code is to be used on ARM's Mbed website, which is an online compiler for the mDot. 

Conduit Configuration file.
	Restores the conduit to the condition it was in during final testing of our system.

Node-RED Code.
	The information in the test file is used to create the nodes used in the final testing
	of our system.  This is the only way to really save out Node-RED code using the Conduit.
	
Each folder contains a ReadMe txt file explaining the process used to access the and use the code.

Any questions email me at : jab3352@louisiana.edu