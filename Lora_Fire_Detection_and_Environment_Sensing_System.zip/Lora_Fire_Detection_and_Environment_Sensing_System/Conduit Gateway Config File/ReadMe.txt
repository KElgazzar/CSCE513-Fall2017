To restore configuration to the configuration found in this file.

Log into the Conduit, using user: admin, pw:admin.

Once in, make your way to the administration tab, and find the restore configuration from file option.

Browse to the configuration file found in this folder, and click restore.

The router should restart, and have the same configuration settings, as seen in the final presentation of our project.

If you have any questions, feel free to email me at : jab3352@louisiana.edu