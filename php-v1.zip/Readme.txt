Networking Project Website Link: http://networking-csce513.us-east-2.elasticbeanstalk.com/

Are you a doctor? Needs to be checked
Username: jjlLabDiag
Password: labDiag1